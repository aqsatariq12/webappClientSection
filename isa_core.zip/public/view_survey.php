<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';

$token = isset($_GET['token']) ? clean($_GET['token']) : null;
if (!$token) die("Access denied.");

$stmt = $pdo->prepare("SELECT * FROM surveys WHERE token = ?");
$stmt->execute([$token]);
$survey = $stmt->fetch();
if (!$survey) die("Survey not found.");

// Load images
$img_stmt = $pdo->prepare("SELECT image FROM survey_images WHERE survey_id = ?");
$img_stmt->execute([$survey['id']]);
$images = $img_stmt->fetchAll(PDO::FETCH_COLUMN);

// Decode JSON
$panel_boxes = json_decode($survey['panel_boxes'], true) ?? [];
$inv1_boxes = json_decode($survey['inverter_1_boxes'], true) ?? [];
$inv2_boxes = json_decode($survey['inverter_2_boxes'], true) ?? [];
$ac_cables = json_decode($survey['ac_cables'], true) ?? [];
$dc_cables = json_decode($survey['dc_cables'], true) ?? [];
$battery_cables = json_decode($survey['battery_cables'], true) ?? [];
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>View Survey</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .section { padding: 10px 15px; border: 1px solid #ccc; margin-bottom: 20px; border-radius: 5px; }
    .section h5 { border-bottom: 1px solid #ddd; margin-bottom: 10px; }
    .image-thumb { width: 120px; height: auto; margin: 5px; border: 1px solid #ccc; padding: 4px; border-radius: 4px; }
  </style>
</head>
<body>
<div class="container mt-4">
  <h4 class="mb-4">Survey Details</h4>

  <div class="section">
    <h5>Basic Info</h5>
    <p><strong>ESA Serial:</strong> <?= htmlspecialchars($survey['esa_serial']) ?></p>
    <p><strong>Date:</strong> <?= date('d M Y', strtotime($survey['created_at'])) ?></p>
    <p><strong>System:</strong> <?= $survey['system_type'] ?> - <?= $survey['system_kw'] ?> KW</p>
  </div>

  <div class="section">
    <h5>Bill Info</h5>
    <p><strong>Bill No:</strong> <?= $survey['bill_no'] ?></p>
    <?php if ($survey['bill_pic']): ?>
      <p><a href="../uploads/<?= $survey['bill_pic'] ?>" target="_blank">View Bill Picture</a></p>
    <?php endif; ?>
  </div>

  <div class="section">
    <h5>Panel Boxes</h5>
    <?php foreach ($panel_boxes as $i => $val): ?>
      <span class="badge bg-primary me-1"><?= htmlspecialchars($val) ?></span>
    <?php endforeach; ?>
  </div>

  <div class="section">
    <h5>AC Cables</h5>
    <?php foreach ($ac_cables as $row): ?>
      <div><?= implode(' | ', $row) ?></div>
    <?php endforeach; ?>
  </div>

  <div class="section">
    <h5>Uploaded Images</h5>
    <div class="d-flex flex-wrap">
      <?php foreach ($images as $img): ?>
        <a href="../uploads/<?= $img ?>" target="_blank"><img src="../uploads/<?= $img ?>" class="image-thumb"></a>
      <?php endforeach; ?>
    </div>
  </div>
</div>
</body>
</html>
