<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

if ($_SESSION['role'] !== 'surveyor') {
    header("Location: ../index.php");
    exit;
}

$survey_id = isset($_GET['id']) ? clean($_GET['id']) : null;
if (!$survey_id) {
    die("Survey ID missing.");
}

$stmt = $pdo->prepare("SELECT * FROM surveys WHERE id = ?");
$stmt->execute([$survey_id]);
$survey = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$survey) die("Survey not found.");

function checked($val) {
    return $val ? 'checked' : '';
}
function e($key) {
    global $survey;
    return htmlspecialchars($survey[$key] ?? '');
}
function renderBoxes($prefix, $json) {
    $boxes = json_decode($json, true) ?? [];
    $html = '<div class="dynamic-boxes">';
    foreach ($boxes as $i => $value) {
        $html .= '<input class="form-control" name="'.$prefix.'_box_' . ($i+1) . '" value="'.htmlspecialchars($value).'" placeholder="'.($i+1).'">';
    }
    $html .= '</div>';
    return $html;
}
function cableInputs($prefix, $json) {
    $data = json_decode($json, true) ?? [];
    $html = '';
    for ($i = 1; $i <= 2; $i++) {
        $d = $data[$i-1] ?? ['name'=>'','core'=>'','mm'=>'','feet'=>'','length'=>''];
        $html .= '<div class="row g-2 mb-2">';
        foreach (['name','core','mm','feet','length'] as $field) {
            $html .= '<div class="col-md-2"><input name="'.$prefix.'_cable_'.$i.'_'.$field.'" class="form-control" value="'.htmlspecialchars($d[$field] ?? '').'" placeholder="'.ucfirst($field).'"></div>';
        }
        $html .= '</div>';
    }
    return $html;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Survey</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .form-section { border: 1px solid #ddd; padding: 15px; margin-bottom: 20px; border-radius: 5px; }
        .form-section h5 { margin-bottom: 15px; background: #f8f9fa; padding: 10px; border-radius: 4px; }
        .dynamic-boxes { display: flex; flex-wrap: wrap; gap: 8px; }
        .dynamic-boxes input { width: 70px; }
    </style>
</head>
<body>
<div class="container mt-4">
    <h4 class="mb-4">Edit Survey</h4>
    <form action="update_survey.php?id=<?= $survey_id ?>" method="POST" enctype="multipart/form-data">

        <!-- ESA Details -->
        <div class="form-section">
            <h5>ESA Details</h5>
            <div class="row mb-2">
                <div class="col-md-4">
                    <label>ESA Serial No</label>
                    <input type="text" name="esa_serial" value="<?= e('esa_serial') ?>" class="form-control" readonly>
                </div>
                <div class="col-md-4">
                    <label>Surveyor</label>
                    <input type="text" class="form-control" value="<?= $_SESSION['user_id'] ?>" readonly>
                    <input type="hidden" name="user_id" value="<?= $_SESSION['user_id'] ?>">
                </div>
                <div class="col-md-4">
                    <label>Date</label>
                    <input type="text" name="date" value="<?= date('d/m/Y', strtotime($survey['created_at'])) ?>" class="form-control" readonly>
                </div>
            </div>
        </div>

        <!-- System Info -->
        <div class="form-section">
            <h5>System & Bill Info</h5>
            <div class="row mb-3">
                <div class="col-md-4"><label>System Type</label><input name="system_type" class="form-control" value="<?= e('system_type') ?>"></div>
                <div class="col-md-4"><label>System (KW)</label><input name="system_kw" class="form-control" value="<?= e('system_kw') ?>"></div>
                <div class="col-md-4">
                    <label>Connection Type</label>
                    <select name="connection_type" class="form-select">
                        <?php foreach (['Residential','Commercial','Industry','Agriculture'] as $type): ?>
                            <option <?= e('connection_type') === $type ? 'selected' : '' ?>><?= $type ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-md-4">
                    <label>Service Type</label>
                    <select name="service_type" class="form-select">
                        <?php foreach (['Net Metering','Enhancement','Others'] as $type): ?>
                            <option <?= e('service_type') === $type ? 'selected' : '' ?>><?= $type ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4"><label>Bill No</label><input name="bill_no" class="form-control" value="<?= e('bill_no') ?>"></div>
                <div class="col-md-4">
                    <label>Bill Picture</label>
                    <input type="file" name="bill_pic" class="form-control">
                    <?php if ($survey['bill_pic']): ?>
                        <a href="../uploads/<?= $survey['bill_pic'] ?>" target="_blank">View</a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="mb-3"><label>Sanction Load</label><input name="sanction_load" class="form-control" value="<?= e('sanction_load') ?>"></div>
        </div>

        <!-- Panels -->
        <div class="form-section">
            <h5>Solar Panel Details</h5>
            <div class="row mb-3">
                <div class="col-md-4"><label>Panel Model No</label><input name="panel_model_no" class="form-control" value="<?= e('panel_model_no') ?>"></div>
                <div class="col-md-4"><label>Panel Type</label><input name="panel_type" class="form-control" value="<?= e('panel_type') ?>"></div>
                <div class="col-md-4"><label>Manufacturer</label><input name="panel_manufacturer" class="form-control" value="<?= e('panel_manufacturer') ?>"></div>
            </div>
            <div class="row mb-3">
                <div class="col-md-4"><label>Panel Power (KW)</label><input name="panel_power" class="form-control" value="<?= e('panel_power') ?>"></div>
                <div class="col-md-4"><label>No. of Panels</label><input name="panel_count" class="form-control" value="<?= e('panel_count') ?>"></div>
                <div class="col-md-4"><label>No. of Boxes</label><input name="panel_box_count" class="form-control" value="<?= e('panel_box_count') ?>"></div>
            </div>
            <div class="mb-3"><label>Panel Box Details</label><?= renderBoxes('panel', $survey['panel_boxes']) ?></div>
            <div class="mb-3">
                <label>Panel Picture</label>
                <input type="file" name="panel_pic" class="form-control">
                <?php if ($survey['panel_pic']): ?>
                    <a href="../uploads/<?= $survey['panel_pic'] ?>" target="_blank">View</a>
                <?php endif; ?>
            </div>
        </div>

        <!-- Inverter 1 & 2 -->
        <?php
        for ($i = 1; $i <= 2; $i++):
            $prefix = "inverter_{$i}";
        ?>
        <div class="form-section">
            <h5>Inverter <?= $i ?></h5>
            <div class="row mb-3">
                <div class="col-md-3"><label>KW</label><input name="<?= $prefix ?>_kw" class="form-control" value="<?= e($prefix . '_kw') ?>"></div>
                <div class="col-md-3"><label>Manufacturer</label><input name="<?= $prefix ?>_manufacturer" class="form-control" value="<?= e($prefix . '_manufacturer') ?>"></div>
                <div class="col-md-3"><label>Model</label><input name="<?= $prefix ?>_model" class="form-control" value="<?= e($prefix . '_model') ?>"></div>
                <div class="col-md-3"><label>ID</label><input name="<?= $prefix ?>_id" class="form-control" value="<?= e($prefix . '_id') ?>"></div>
            </div>
            <div class="row mb-3">
                <div class="col-md-6"><label>Password</label><input name="<?= $prefix ?>_password" class="form-control" value="<?= e($prefix . '_password') ?>"></div>
                <div class="col-md-6"><label>Picture</label><input type="file" name="<?= $prefix ?>_pic" class="form-control">
                    <?php if ($survey[$prefix . '_pic']): ?>
                        <a href="../uploads/<?= $survey[$prefix . '_pic'] ?>" target="_blank">View</a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-md-4"><label>No. of Panels</label><input name="<?= $prefix ?>_panel_count" class="form-control" value="<?= e($prefix . '_panel_count') ?>"></div>
                <div class="col-md-4"><label>No. of Boxes</label><input name="<?= $prefix ?>_box_count" class="form-control" value="<?= e($prefix . '_box_count') ?>"></div>
            </div>
            <div class="mb-3"><label>Box Details</label><?= renderBoxes("inv{$i}", $survey[$prefix . '_boxes']) ?></div>
        </div>
        <?php endfor; ?>

        <!-- Battery -->
        <div class="form-section">
            <h5>Battery Details</h5>
            <div class="form-check form-switch mb-3">
                <input class="form-check-input" type="checkbox" name="battery_installed" value="1" <?= checked($survey['battery_installed']) ?>>
                <label class="form-check-label">Battery Installed</label>
            </div>
            <?php for ($i = 1; $i <= 3; $i++): ?>
                <div class="card mb-3">
                    <div class="card-header">Battery <?= $i ?></div>
                    <div class="card-body row g-3">
                        <?php foreach (['name','model','type','serial','volt','amp','cell'] as $field): ?>
                            <div class="col-md-3">
                                <input name="battery_<?= $i ?>_<?= $field ?>" class="form-control"
                                       placeholder="<?= ucfirst($field) ?>"
                                       value="<?= e("battery_{$i}_{$field}") ?>">
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endfor; ?>
        </div>

        <!-- Cable -->
        <div class="form-section">
            <h5>Cable Details</h5>
            <?php foreach (['ac' => 'AC', 'dc' => 'DC', 'battery' => 'Battery'] as $prefix => $label): ?>
                <h6><?= $label ?> Cables</h6>
                <?= cableInputs($prefix, $survey[$prefix.'_cables']) ?>
            <?php endforeach; ?>
        </div>

        <!-- Other -->
        <div class="form-section">
            <h5>Other Equipment</h5>
            <div class="row">
                <?php foreach (['light_arrester','smart_controller','zero_export','light_earthing','delta_hub','ac_earthing','dc_earthing'] as $key): ?>
                    <div class="col-md-4">
                        <div class="form-check">
                            <input type="checkbox" name="<?= $key ?>" value="1" <?= checked($survey[$key]) ?> class="form-check-input" id="<?= $key ?>">
                            <label for="<?= $key ?>" class="form-check-label text-capitalize"><?= str_replace('_', ' ', $key) ?></label>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Final -->
        <div class="form-section">
            <h5>Net Metering Status</h5>
            <select name="net_metering_progress" class="form-select mb-3">
                <?php foreach (['Application Submission','Survey & Drawing','Estimate Issuance','Estimate & SD Payment Recieved','Test Form Submission (Except Net Metering)','Material & Execution','Energisation','Case Completed'] as $status): ?>
                    <option <?= e('net_metering_progress') === $status ? 'selected' : '' ?>><?= $status ?></option>
                <?php endforeach; ?>
            </select>
            <label>Notes</label>
            <textarea name="notes" class="form-control" rows="3"><?= e('notes') ?></textarea>
        </div>

        <div class="d-grid">
            <button class="btn btn-primary">Update Survey</button>
        </div>
    </form>
</div>
</body>
</html>
