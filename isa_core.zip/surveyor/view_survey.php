<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';

if ($_SESSION['role'] !== 'surveyor') {
    header("Location: ../index.php");
    exit;
}

$survey_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$stmt = $pdo->prepare("SELECT * FROM surveys WHERE id = ?");
$stmt->execute([$survey_id]);
$data = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$data) {
    echo "Survey not found.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Survey Details</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .form-section {
      border: 1px solid #ddd;
      padding: 15px;
      margin-bottom: 20px;
      border-radius: 5px;
    }
    .form-section h5 {
      margin-bottom: 15px;
      background: #f8f9fa;
      padding: 10px;
      border-radius: 4px;
    }
    .dynamic-boxes {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
    }
    .dynamic-boxes input {
      width: 70px;
    }
    label {
      font-weight: bold;
    }
  </style>
</head>
<body>
<div class="container mt-4">
  <h4 class="mb-4">Survey Details</h4>

  <!-- ESA Details -->
  <div class="form-section">
    <h5>ESA Details</h5>
    <div class="row mb-2">
      <div class="col-md-4"><label>ESA Serial</label><p><?= $data['esa_serial'] ?></p></div>
      <div class="col-md-4"><label>Surveyor ID</label><p><?= $data['user_id'] ?></p></div>
      <div class="col-md-4"><label>Date</label><p><?= date('d/m/Y', strtotime($data['created_at'])) ?></p></div>
    </div>
  </div>

  <!-- System Info -->
  <div class="form-section">
    <h5>System & Bill Info</h5>
    <div class="row mb-3">
      <div class="col-md-4"><label>System Type</label><p><?= $data['system_type'] ?></p></div>
      <div class="col-md-4"><label>KW</label><p><?= $data['system_kw'] ?></p></div>
      <div class="col-md-4"><label>Connection Type</label><p><?= $data['connection_type'] ?></p></div>
    </div>
    <div class="row mb-3">
      <div class="col-md-4"><label>Service Type</label><p><?= $data['service_type'] ?></p></div>
      <div class="col-md-4"><label>Bill No</label><p><?= $data['bill_no'] ?></p></div>
      <div class="col-md-4"><label>Sanction Load</label><p><?= $data['sanction_load'] ?></p></div>
    </div>
    <div class="mb-3">
      <label>Bill Picture</label><br>
      <?php if ($data['bill_pic']): ?>
        <img src="../uploads/<?= $data['bill_pic'] ?>" alt="Bill Picture" class="img-fluid rounded" style="max-height: 200px;">
      <?php else: ?>
        <p>No file uploaded</p>
      <?php endif; ?>
    </div>
  </div>

  <!-- Other sections like Panel, Inverter, Battery, Cables, and Equipment will follow similar structure -->
  <!-- Panel Details -->
	<div class="form-section">
	  <h5>Solar Panel Details</h5>
	  <div class="row mb-3">
		<div class="col-md-4"><label>Model No</label><p><?= $data['panel_model_no'] ?></p></div>
		<div class="col-md-4"><label>Type</label><p><?= $data['panel_type'] ?></p></div>
		<div class="col-md-4"><label>Manufacturer</label><p><?= $data['panel_manufacturer'] ?></p></div>
	  </div>
	  <div class="row mb-3">
		<div class="col-md-4"><label>Power (KW)</label><p><?= $data['panel_power'] ?></p></div>
		<div class="col-md-4"><label>No. of Panels</label><p><?= $data['panel_count'] ?></p></div>
		<div class="col-md-4"><label>No. of Boxes</label><p><?= $data['panel_box_count'] ?></p></div>
	  </div>
	  <div class="mb-3">
		<label>Box Values</label><br>
		<?php
		  $panel_boxes = json_decode($data['panel_boxes'], true) ?? [];
		  foreach ($panel_boxes as $val) {
			echo '<span class="badge bg-secondary me-1 mb-1">' . htmlspecialchars($val) . '</span>';
		  }
		?>
	  </div>
	  <div class="mb-3">
		<label>Panel Picture</label><br>
		<?php if ($data['panel_pic']): ?>
		  <img src="../uploads/<?= $data['panel_pic'] ?>" alt="Panel Pic" class="img-fluid rounded" style="max-height: 200px;">
		<?php else: ?>
		  <p>No image uploaded.</p>
		<?php endif; ?>
	  </div>
	</div>

	<!-- Inverter Details -->
	<?php for ($i = 1; $i <= 2; $i++): ?>
	<div class="form-section">
	  <h5>Inverter <?= $i ?></h5>
	  <div class="row mb-3">
		<div class="col-md-4"><label>KW</label><p><?= $data["inverter_{$i}_kw"] ?></p></div>
		<div class="col-md-4"><label>Manufacturer</label><p><?= $data["inverter_{$i}_manufacturer"] ?></p></div>
		<div class="col-md-4"><label>Model</label><p><?= $data["inverter_{$i}_model"] ?></p></div>
	  </div>
	  <div class="row mb-3">
		<div class="col-md-4"><label>ID</label><p><?= $data["inverter_{$i}_id"] ?></p></div>
		<div class="col-md-4"><label>Password</label><p><?= $data["inverter_{$i}_password"] ?></p></div>
		<div class="col-md-4"><label>Panel Count</label><p><?= $data["inverter_{$i}_panel_count"] ?></p></div>
	  </div>
	  <div class="mb-3">
		<label>Box Values</label><br>
		<?php
		  $inv_boxes = json_decode($data["inverter_{$i}_boxes"], true) ?? [];
		  foreach ($inv_boxes as $val) {
			echo '<span class="badge bg-info text-dark me-1 mb-1">' . htmlspecialchars($val) . '</span>';
		  }
		?>
	  </div>
	  <div class="mb-3">
		<label>Inverter Picture</label><br>
		<?php if ($data["inverter_{$i}_pic"]): ?>
		  <img src="../uploads/<?= $data["inverter_{$i}_pic"] ?>" alt="Inverter <?= $i ?>" class="img-fluid rounded" style="max-height: 200px;">
		<?php else: ?>
		  <p>No image uploaded.</p>
		<?php endif; ?>
	  </div>
	</div>
	<?php endfor; ?>

	<!-- Battery Section -->
	<?php if ($data['battery_installed']): ?>
	<div class="form-section">
	  <h5>Battery Details</h5>
	  <?php for ($i = 1; $i <= 3; $i++): ?>
		<?php if ($data["battery_{$i}_name"]): ?>
		<div class="card mb-3">
		  <div class="card-header">Battery <?= $i ?></div>
		  <div class="card-body row g-2">
			<div class="col-md-3"><label>Name</label><p><?= $data["battery_{$i}_name"] ?></p></div>
			<div class="col-md-3"><label>Model</label><p><?= $data["battery_{$i}_model"] ?></p></div>
			<div class="col-md-3"><label>Type</label><p><?= $data["battery_{$i}_type"] ?></p></div>
			<div class="col-md-3"><label>Serial #</label><p><?= $data["battery_{$i}_serial"] ?></p></div>
			<div class="col-md-2"><label>Volt</label><p><?= $data["battery_{$i}_volt"] ?></p></div>
			<div class="col-md-2"><label>Amp</label><p><?= $data["battery_{$i}_amp"] ?></p></div>
			<div class="col-md-2"><label>Cell</label><p><?= $data["battery_{$i}_cell"] ?></p></div>
		  </div>
		</div>
		<?php endif; ?>
	  <?php endfor; ?>
	</div>
	<?php endif; ?>

	<!-- Cable Details -->
	<div class="form-section">
	  <h5>Cable Details</h5>
	  <?php foreach (['ac'=>'AC', 'dc'=>'DC', 'battery'=>'Battery'] as $key => $label): ?>
	  <h6><?= $label ?> Cables</h6>
	  <?php
		$cables = json_decode($data[$key.'_cables'], true) ?? [];
		foreach ($cables as $cable):
	  ?>
		<div class="row mb-2">
		  <?php foreach (['name','core','mm','feet','length'] as $field): ?>
		  <div class="col-md-2"><label><?= ucfirst($field) ?></label><p><?= htmlspecialchars($cable[$field] ?? '') ?></p></div>
		  <?php endforeach; ?>
		</div>
	  <?php endforeach; ?>
	  <?php endforeach; ?>
	</div>

	<!-- Other Equipment -->
	<div class="form-section">
	  <h5>Other Equipment</h5>
	  <div class="row">
		<?php foreach (['light_arrester','smart_controller','zero_export','light_earthing','delta_hub','ac_earthing','dc_earthing'] as $key): ?>
		  <div class="col-md-4 mb-2">
			<strong><?= ucwords(str_replace('_',' ',$key)) ?>:</strong> <?= $data[$key] ? 'Yes' : 'No' ?>
		  </div>
		<?php endforeach; ?>
	  </div>
	</div>

	<!-- Net Metering -->
	<div class="form-section">
	  <h5>Net Metering Status</h5>
	  <p><?= $data['net_metering_progress'] ?></p>
	</div>
	
	<!-- Other Attachments -->
	<div class="form-section">
	  <h5>Other Attachments</h5>
	  <?php
		$attachmentStmt = $pdo->prepare("SELECT * FROM survey_images WHERE survey_id = ?");
		$attachmentStmt->execute([$survey_id]);
		$attachments = $attachmentStmt->fetchAll(PDO::FETCH_ASSOC);

		if (count($attachments) > 0):
	  ?>
		<ul class="list-group">
		  <?php foreach ($attachments as $file): ?>
			<li class="list-group-item d-flex justify-content-between align-items-center">
			  <?= htmlspecialchars($file['image_type']) ?>
			  <a href="../uploads/<?= urlencode($file['image_path']) ?>" class="btn btn-sm btn-outline-primary" target="_blank">View</a>
			</li>
		  <?php endforeach; ?>
		</ul>
	  <?php else: ?>
		<p>No additional attachments found.</p>
	  <?php endif; ?>
	</div>




  <div class="form-section">
    <h5>Additional Notes</h5>
    <p><?= nl2br(htmlspecialchars($data['notes'])) ?></p>
  </div>
</div>
</body>
</html>
