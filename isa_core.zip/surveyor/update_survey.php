<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

if ($_SESSION['role'] !== 'surveyor') {
    header("Location: ../index.php");
    exit;
}

function uploadFile($field, $existing = null) {
    if (isset($_FILES[$field]) && $_FILES[$field]['error'] === 0) {
        $ext = pathinfo($_FILES[$field]['name'], PATHINFO_EXTENSION);
        $newName = uniqid($field . '_') . '.' . $ext;
        move_uploaded_file($_FILES[$field]['tmp_name'], '../uploads/' . $newName);
        return $newName;
    }
    return $existing;
}

function jsonCable($prefix) {
    $result = [];
    for ($i = 1; $i <= 2; $i++) {
        $row = [
            'name' => clean($_POST["{$prefix}_cable_{$i}_name"] ?? ''),
            'core' => clean($_POST["{$prefix}_cable_{$i}_core"] ?? ''),
            'mm'   => clean($_POST["{$prefix}_cable_{$i}_mm"] ?? ''),
            'feet' => clean($_POST["{$prefix}_cable_{$i}_feet"] ?? ''),
            'length' => clean($_POST["{$prefix}_cable_{$i}_length"] ?? '')
        ];
        if (array_filter($row)) $result[] = $row;
    }
    return json_encode($result);
}

function jsonBoxes($prefix) {
    $result = [];
    foreach ($_POST as $key => $val) {
        if (strpos($key, "{$prefix}_box_") === 0) {
            $result[] = clean($val);
        }
    }
    return json_encode($result);
}

$survey_id = clean($_GET['id']);

$stmt = $pdo->prepare("SELECT * FROM surveys WHERE id = ?");
$stmt->execute([$survey_id]);
$old = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$old) die("Survey not found");

$checkboxes = ['light_arrester','smart_controller','zero_export','light_earthing','delta_hub','ac_earthing','dc_earthing'];
foreach ($checkboxes as $cb) {
    $_POST[$cb] = isset($_POST[$cb]) ? 1 : 0;
}
$battery_installed = isset($_POST['battery_installed']) ? 1 : 0;

$update = $pdo->prepare("UPDATE surveys SET
    esa_serial=?, user_id=?, system_type=?, system_kw=?, connection_type=?, service_type=?, bill_no=?, bill_pic=?, sanction_load=?,
    panel_model_no=?, panel_type=?, panel_manufacturer=?, panel_power=?, panel_count=?, panel_box_count=?, panel_boxes=?, panel_pic=?,
    inverter_count=?, inverter_1_kw=?, inverter_1_manufacturer=?, inverter_1_model=?, inverter_1_id=?, inverter_1_password=?, inverter_1_pic=?, inverter_1_panel_count=?, inverter_1_box_count=?, inverter_1_boxes=?,
    inverter_2_kw=?, inverter_2_manufacturer=?, inverter_2_model=?, inverter_2_id=?, inverter_2_password=?, inverter_2_pic=?, inverter_2_panel_count=?, inverter_2_box_count=?, inverter_2_boxes=?,
    battery_installed=?, battery_1_name=?, battery_1_model=?, battery_1_type=?, battery_1_serial=?, battery_1_volt=?, battery_1_amp=?, battery_1_cell=?,
    battery_2_name=?, battery_2_model=?, battery_2_type=?, battery_2_serial=?, battery_2_volt=?, battery_2_amp=?, battery_2_cell=?,
    battery_3_name=?, battery_3_model=?, battery_3_type=?, battery_3_serial=?, battery_3_volt=?, battery_3_amp=?, battery_3_cell=?,
    ac_cables=?, dc_cables=?, battery_cables=?,
    light_arrester=?, smart_controller=?, zero_export=?, light_earthing=?, delta_hub=?, ac_earthing=?, dc_earthing=?,
    net_metering_progress=?, notes=?
WHERE id=?");

$update->execute([
    clean($_POST['esa_serial']),
    clean($_POST['user_id']),
    clean($_POST['system_type']),
    clean($_POST['system_kw']),
    clean($_POST['connection_type']),
    clean($_POST['service_type']),
    clean($_POST['bill_no']),
    uploadFile('bill_pic', $old['bill_pic']),
    clean($_POST['sanction_load']),

    clean($_POST['panel_model_no']),
    clean($_POST['panel_type']),
    clean($_POST['panel_manufacturer']),
    clean($_POST['panel_power']),
    clean($_POST['panel_count']),
    clean($_POST['panel_box_count']),
    jsonBoxes('panel'),
    uploadFile('panel_pic', $old['panel_pic']),

    2, // inverter_count static

    clean($_POST['inverter_1_kw']),
    clean($_POST['inverter_1_manufacturer']),
    clean($_POST['inverter_1_model']),
    clean($_POST['inverter_1_id']),
    clean($_POST['inverter_1_password']),
    uploadFile('inverter_1_pic', $old['inverter_1_pic']),
    clean($_POST['inverter_1_panel_count']),
    clean($_POST['inverter_1_box_count']),
    jsonBoxes('inv1'),

    clean($_POST['inverter_2_kw']),
    clean($_POST['inverter_2_manufacturer']),
    clean($_POST['inverter_2_model']),
    clean($_POST['inverter_2_id']),
    clean($_POST['inverter_2_password']),
    uploadFile('inverter_2_pic', $old['inverter_2_pic']),
    clean($_POST['inverter_2_panel_count']),
    clean($_POST['inverter_2_box_count']),
    jsonBoxes('inv2'),

    $battery_installed,
    clean($_POST['battery_1_name']),
    clean($_POST['battery_1_model']),
    clean($_POST['battery_1_type']),
    clean($_POST['battery_1_serial']),
    clean($_POST['battery_1_volt']),
    clean($_POST['battery_1_amp']),
    clean($_POST['battery_1_cell']),

    clean($_POST['battery_2_name']),
    clean($_POST['battery_2_model']),
    clean($_POST['battery_2_type']),
    clean($_POST['battery_2_serial']),
    clean($_POST['battery_2_volt']),
    clean($_POST['battery_2_amp']),
    clean($_POST['battery_2_cell']),

    clean($_POST['battery_3_name']),
    clean($_POST['battery_3_model']),
    clean($_POST['battery_3_type']),
    clean($_POST['battery_3_serial']),
    clean($_POST['battery_3_volt']),
    clean($_POST['battery_3_amp']),
    clean($_POST['battery_3_cell']),

    jsonCable('ac'),
    jsonCable('dc'),
    jsonCable('battery'),

    $_POST['light_arrester'],
    $_POST['smart_controller'],
    $_POST['zero_export'],
    $_POST['light_earthing'],
    $_POST['delta_hub'],
    $_POST['ac_earthing'],
    $_POST['dc_earthing'],

    clean($_POST['net_metering_progress']),
    clean($_POST['notes']),
    $survey_id
]);

header("Location: edit_survey.php?id=$survey_id&updated=1");
exit;
?>
