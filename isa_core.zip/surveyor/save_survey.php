<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

echo clean($_GET['client_id']);

function uploadFile($field, $prefix = '') {
    if (isset($_FILES[$field]) && $_FILES[$field]['error'] === 0) {
        $ext = pathinfo($_FILES[$field]['name'], PATHINFO_EXTENSION);
        $filename = $prefix . uniqid() . '.' . $ext;
        $dest = '../uploads/' . $filename;
        move_uploaded_file($_FILES[$field]['tmp_name'], $dest);
        return $filename;
    }
    return null;
}

function buildCableJson($prefix) {
    $data = [];
    for ($i = 1; $i <= 2; $i++) {
        $row = [
            'name'   => clean($_POST["{$prefix}_cable_{$i}_name"]),
            'core'   => clean($_POST["{$prefix}_cable_{$i}_core"]),
            'mm'     => clean($_POST["{$prefix}_cable_{$i}_mm"]),
            'feet'   => clean($_POST["{$prefix}_cable_{$i}_feet"]),
            'length' => clean($_POST["{$prefix}_cable_{$i}_length"]),
        ];
        if (array_filter($row)) $data[] = $row;
    }
    return json_encode($data);
}

function battery($i, $field) {
    return clean($_POST["battery_{$i}_{$field}"] ?? '');
}

// Panel boxes
$panel_box_count = (int) $_POST['panel_box_count'];
$panel_boxes = [];
for ($i = 1; $i <= $panel_box_count; $i++) {
    $key = 'panel_box_' . $i;
    if (isset($_POST[$key])) $panel_boxes[] = clean($_POST[$key]);
}

// Inverter 1
$inv1_box_count = (int) ($_POST['inverter_1_box_count'] ?? 0);
$inv1_boxes = [];
for ($i = 1; $i <= $inv1_box_count; $i++) {
    $key = 'inv1_box_' . $i;
    if (isset($_POST[$key])) $inv1_boxes[] = clean($_POST[$key]);
}

// Inverter 2
$inv2_box_count = (int) ($_POST['inverter_2_box_count'] ?? 0);
$inv2_boxes = [];
for ($i = 1; $i <= $inv2_box_count; $i++) {
    $key = 'inv2_box_' . $i;
    if (isset($_POST[$key])) $inv2_boxes[] = clean($_POST[$key]);
}

// File uploads
$bill_pic        = uploadFile('bill_pic', 'bill_');
$panel_pic       = uploadFile('panel_pic', 'panel_');
$inverter_1_pic  = uploadFile('inverter_1_pic', 'inv1_');
$inverter_2_pic  = uploadFile('inverter_2_pic', 'inv2_');

// Others checkboxes
$checkboxes = ['light_arrester', 'smart_controller', 'zero_export', 'light_earthing', 'delta_hub', 'ac_earthing', 'dc_earthing'];
$flags = [];
foreach ($checkboxes as $key) {
    $flags[$key] = isset($_POST[$key]) ? 1 : 0;
}

// Final insert
$stmt = $pdo->prepare("INSERT INTO surveys (
    esa_serial, token, client_id, user_id, created_at,
    system_type, system_kw, connection_type, service_type, bill_no, bill_pic, sanction_load,
    panel_model_no, panel_type, panel_manufacturer, panel_power, panel_count, panel_box_count, panel_boxes, panel_pic,
    inverter_count,
    inverter_1_kw, inverter_1_manufacturer, inverter_1_model, inverter_1_id, inverter_1_password, inverter_1_pic, inverter_1_panel_count, inverter_1_box_count, inverter_1_boxes,
    inverter_2_kw, inverter_2_manufacturer, inverter_2_model, inverter_2_id, inverter_2_password, inverter_2_pic, inverter_2_panel_count, inverter_2_box_count, inverter_2_boxes,
    battery_installed,
    battery_1_name, battery_1_model, battery_1_type, battery_1_serial, battery_1_volt, battery_1_amp, battery_1_cell,
    battery_2_name, battery_2_model, battery_2_type, battery_2_serial, battery_2_volt, battery_2_amp, battery_2_cell,
    battery_3_name, battery_3_model, battery_3_type, battery_3_serial, battery_3_volt, battery_3_amp, battery_3_cell,
    ac_cables, dc_cables, battery_cables,
    light_arrester, smart_controller, zero_export, light_earthing, delta_hub, ac_earthing, dc_earthing,
    net_metering_progress, notes
) VALUES (
    ?, ?, ?, ?, NOW(),
    ?, ?, ?, ?, ?, ?, ?,
    ?, ?, ?, ?, ?, ?, ?, ?,
    ?,
    ?, ?, ?, ?, ?, ?, ?, ?, ?,
    ?, ?, ?, ?, ?, ?, ?, ?, ?,
    ?,
    ?, ?, ?, ?, ?, ?, ?,
    ?, ?, ?, ?, ?, ?, ?,
    ?, ?, ?, ?, ?, ?, ?,
    ?, ?, ?,
    ?, ?, ?, ?, ?, ?, ?,
    ?, ?
)");

$stmt->execute([
    clean($_POST['esa_serial']),
    bin2hex(random_bytes(32)),
    clean($_GET['client_id'] ?? null),
    $_SESSION['user_id'],

    clean($_POST['system_type']),
    clean($_POST['system_kw']),
    clean($_POST['connection_type']),
    clean($_POST['service_type']),
    clean($_POST['bill_no']),
    $bill_pic,
    clean($_POST['sanction_load']),

    clean($_POST['panel_model_no']),
    clean($_POST['panel_type']),
    clean($_POST['panel_manufacturer']),
    clean($_POST['panel_power']),
    clean($_POST['panel_count']),
    $panel_box_count,
    json_encode($panel_boxes),
    $panel_pic,

    clean($_POST['inverter_count']),
    clean($_POST['inverter_1_kw']),
    clean($_POST['inverter_1_manufacturer']),
    clean($_POST['inverter_1_model']),
    clean($_POST['inverter_1_id']),
    clean($_POST['inverter_1_password']),
    $inverter_1_pic,
    clean($_POST['inverter_1_panel_count']),
    $inv1_box_count,
    json_encode($inv1_boxes),

    clean($_POST['inverter_2_kw']),
    clean($_POST['inverter_2_manufacturer']),
    clean($_POST['inverter_2_model']),
    clean($_POST['inverter_2_id']),
    clean($_POST['inverter_2_password']),
    $inverter_2_pic,
    clean($_POST['inverter_2_panel_count']),
    $inv2_box_count,
    json_encode($inv2_boxes),

    isset($_POST['battery_installed']) ? 1 : 0,
    battery(1, 'name'), battery(1, 'model'), battery(1, 'type'), battery(1, 'serial'), battery(1, 'volt'), battery(1, 'amp'), battery(1, 'cell'),
    battery(2, 'name'), battery(2, 'model'), battery(2, 'type'), battery(2, 'serial'), battery(2, 'volt'), battery(2, 'amp'), battery(2, 'cell'),
    battery(3, 'name'), battery(3, 'model'), battery(3, 'type'), battery(3, 'serial'), battery(3, 'volt'), battery(3, 'amp'), battery(3, 'cell'),

    buildCableJson('ac'),
    buildCableJson('dc'),
    buildCableJson('battery'),

    $flags['light_arrester'], $flags['smart_controller'], $flags['zero_export'],
    $flags['light_earthing'], $flags['delta_hub'], $flags['ac_earthing'], $flags['dc_earthing'],
    clean($_POST['net_metering_progress']),
    clean($_POST['notes']),
]);

$survey_id = $pdo->lastInsertId();
header("Location: upload_images.php?survey_id=$survey_id");
exit;
