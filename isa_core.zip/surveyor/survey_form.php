<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

if ($_SESSION['role'] !== 'surveyor') {
    header("Location: ../index.php");
    exit;
}

$client_id = isset($_GET['client_id']) ? clean($_GET['client_id']) : null;

// Auto-generate ESA Serial
$stmt = $pdo->query("SELECT MAX(id) as last_id FROM surveys");
$last_id = $stmt->fetchColumn() + 1;
$esa_serial = "SURV-" . str_pad($last_id, 3, '0', STR_PAD_LEFT) . "/" . date('m') . "/" . date('Y');

// Surveyor info
$user_id = $_SESSION['user_id'];
$user_name_stmt = $pdo->prepare("SELECT name FROM users WHERE id = ?");
$user_name_stmt->execute([$user_id]);
$user_name = $user_name_stmt->fetchColumn();

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>New Survey</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .form-section { border: 1px solid #ddd; padding: 15px; margin-bottom: 20px; border-radius: 5px; }
    .form-section h5 { margin-bottom: 15px; background: #f8f9fa; padding: 10px; border-radius: 4px; }
    .dynamic-boxes { display: flex; flex-wrap: wrap; gap: 8px; }
    .dynamic-boxes input { width: 70px; }
  </style>
</head>
<body>
<div class="container mt-4">
  <h4 class="mb-4">Survey Form</h4>

  <form action="save_survey.php?client_id=<?= $client_id ?>" method="POST" enctype="multipart/form-data">
	<input type="hidden" name="client_id)" value="<?= $client_id ?>">
    <div class="form-section">
      <h5>ESA Details</h5>
      <div class="row mb-2">
        <div class="col-md-4">
          <label>ESA Serial No</label>
          <input type="text" name="esa_serial" value="<?= $esa_serial ?>" class="form-control" readonly>
        </div>
        <div class="col-md-4">
          <label>Surveyor</label>
          <input type="text" class="form-control" value="<?= htmlspecialchars($user_name) ?>" readonly>
          <input type="hidden" name="user_id" value="<?= $user_id ?>">
        </div>
        <div class="col-md-4">
          <label>Date</label>
          <input type="text" name="date" value="<?= date('d/m/Y') ?>" class="form-control" readonly>
        </div>
      </div>
    </div>

    <div class="form-section">
      <h5>System & Bill Info</h5>
      <div class="row mb-3">
        <div class="col-md-4">
          <label>System Type</label>
          <input type="text" name="system_type" class="form-control" required>
        </div>
        <div class="col-md-4">
          <label>System (KW)</label>
          <input type="number" step="0.01" name="system_kw" class="form-control" required>
        </div>
        <div class="col-md-4">
          <label>Connection Type</label>
          <select name="connection_type" class="form-select">
            <option>Residential</option>
            <option>Commercial</option>
            <option>Industry</option>
            <option>Agriculture</option>
          </select>
        </div>
      </div>

      <div class="row mb-3">
        <div class="col-md-4">
          <label>Service Type</label>
          <select name="service_type" class="form-select">
            <option>Net Metering</option>
            <option>Enhancement</option>
            <option>Others</option>
          </select>
        </div>
        <div class="col-md-4">
          <label>Bill No</label>
          <input type="text" name="bill_no" class="form-control">
        </div>
        <div class="col-md-4">
          <label>Bill Picture</label>
          <input type="file" name="bill_pic" class="form-control">
        </div>
      </div>

      <div class="mb-3">
        <label>Sanction Load</label>
        <input type="text" name="sanction_load" class="form-control">
      </div>
    </div>

    <div class="form-section">
      <h5>Solar Panel Details</h5>
      <div class="row mb-3">
        <div class="col-md-4">
          <label>Panel Model No</label>
          <input type="text" name="panel_model_no" class="form-control">
        </div>
        <div class="col-md-4">
          <label>Panel Type</label>
          <select name="panel_type" class="form-select">
            <option>Poly Cristalline</option>
            <option>Mono Cristalline</option>
            <option>Thin film</option>
            <option>Bifacial</option>
            <option>Others</option>
          </select>
        </div>
        <div class="col-md-4">
          <label>Manufacturer</label>
          <select name="panel_manufacturer" class="form-select">
            <option>Longi</option>
            <option>Jinko</option>
            <option>Canadian</option>
            <option>Phono</option>
            <option>JA</option>
          </select>
        </div>
      </div>

      <div class="row mb-3">
        <div class="col-md-4">
          <label>Panel Power (KW)</label>
          <input type="text" name="panel_power" class="form-control">
        </div>
        <div class="col-md-4">
          <label>No. of Panels</label>
          <input type="number" name="panel_count" id="panelCount" class="form-control" min="1" max="24">
        </div>
        <div class="col-md-4">
          <label>Panel Boxes</label>
          <input type="number" name="panel_box_count" id="panelBoxCount" class="form-control" min="1" max="24">
        </div>
      </div>

      <div class="mb-3">
        <label>Panel Box Details</label>
        <div id="panelBoxInputs" class="dynamic-boxes"></div>
      </div>

      <div class="mb-3">
        <label>Panel Picture</label>
        <input type="file" name="panel_pic" class="form-control">
      </div>
    </div>
    <div class="form-section">
      <h5>Inverter Details</h5>
      <div class="mb-3">
        <label>No. of Inverters</label>
        <input type="number" name="inverter_count" id="inverterCount" class="form-control" min="1" max="2" value="1">
      </div>

      <!-- Inverter 1 -->
      <div id="inverter1" class="inverter-group">
        <h6>Inverter 1</h6>
        <div class="row mb-2">
          <div class="col-md-3"><label>KW</label><input type="text" name="inverter_1_kw" class="form-control"></div>
          <div class="col-md-3"><label>Manufacturer</label><input type="text" name="inverter_1_manufacturer" class="form-control"></div>
          <div class="col-md-3"><label>Model</label><input type="text" name="inverter_1_model" class="form-control"></div>
          <div class="col-md-3"><label>Inverter ID</label><input type="text" name="inverter_1_id" class="form-control"></div>
        </div>
        <div class="row mb-2">
          <div class="col-md-6"><label>Password</label><input type="text" name="inverter_1_password" class="form-control"></div>
          <div class="col-md-6"><label>Picture</label><input type="file" name="inverter_1_pic" class="form-control"></div>
        </div>
        <div class="row mb-2">
          <div class="col-md-4"><label>No. of Panels</label><input type="number" name="inverter_1_panel_count" class="form-control"></div>
          <div class="col-md-4"><label>No. of Boxes</label><input type="number" name="inverter_1_box_count" id="inv1BoxCount" class="form-control"></div>
        </div>
        <div class="mb-3">
          <label>Box Details</label>
          <div id="inv1BoxInputs" class="dynamic-boxes"></div>
        </div>
      </div>

      <!-- Inverter 2 -->
      <div id="inverter2" class="inverter-group" style="display: none;">
        <h6>Inverter 2</h6>
        <div class="row mb-2">
          <div class="col-md-3"><label>KW</label><input type="text" name="inverter_2_kw" class="form-control"></div>
          <div class="col-md-3"><label>Manufacturer</label><input type="text" name="inverter_2_manufacturer" class="form-control"></div>
          <div class="col-md-3"><label>Model</label><input type="text" name="inverter_2_model" class="form-control"></div>
          <div class="col-md-3"><label>Inverter ID</label><input type="text" name="inverter_2_id" class="form-control"></div>
        </div>
        <div class="row mb-2">
          <div class="col-md-6"><label>Password</label><input type="text" name="inverter_2_password" class="form-control"></div>
          <div class="col-md-6"><label>Picture</label><input type="file" name="inverter_2_pic" class="form-control"></div>
        </div>
        <div class="row mb-2">
          <div class="col-md-4"><label>No. of Panels</label><input type="number" name="inverter_2_panel_count" class="form-control"></div>
          <div class="col-md-4"><label>No. of Boxes</label><input type="number" name="inverter_2_box_count" id="inv2BoxCount" class="form-control"></div>
        </div>
        <div class="mb-3">
          <label>Box Details</label>
          <div id="inv2BoxInputs" class="dynamic-boxes"></div>
        </div>
      </div>
    </div>

    <div class="form-section">
      <h5>Battery Details</h5>
      <div class="form-check form-switch mb-3">
        <input class="form-check-input" type="checkbox" role="switch" id="batteryInstalled" name="battery_installed" value="1">
        <label class="form-check-label" for="batteryInstalled">Battery Installed</label>
      </div>

      <div id="batterySection" style="display: none;">
        <?php for ($i = 1; $i <= 3; $i++): ?>
        <div class="card mb-3">
          <div class="card-header bg-light">Battery <?= $i ?></div>
          <div class="card-body row g-3">
            <div class="col-md-3"><input name="battery_<?= $i ?>_name" class="form-control" placeholder="Name"></div>
            <div class="col-md-3"><input name="battery_<?= $i ?>_model" class="form-control" placeholder="Model"></div>
            <div class="col-md-3"><input name="battery_<?= $i ?>_type" class="form-control" placeholder="Type"></div>
            <div class="col-md-3"><input name="battery_<?= $i ?>_serial" class="form-control" placeholder="Serial #"></div>
            <div class="col-md-2"><input name="battery_<?= $i ?>_volt" class="form-control" placeholder="Volt"></div>
            <div class="col-md-2"><input name="battery_<?= $i ?>_amp" class="form-control" placeholder="Amp"></div>
            <div class="col-md-2"><input name="battery_<?= $i ?>_cell" class="form-control" placeholder="Cell"></div>
          </div>
        </div>
        <?php endfor; ?>
      </div>
    </div>
    <div class="form-section">
	  <h5>Cable Details</h5>

	  <?php
	  $types = ['ac' => 'AC', 'dc' => 'DC', 'battery' => 'Battery'];
	  foreach ($types as $prefix => $label):
	  ?>
		<div class="mb-3">
		  <h6><?= $label ?> Cables</h6>
		  <?php for ($i = 1; $i <= 2; $i++): ?>
			<div class="row g-2 mb-2">
			  <div class="col-md-2"><input name="<?= $prefix ?>_cable_<?= $i ?>_name" class="form-control" placeholder="Name"></div>
			  <div class="col-md-2"><input name="<?= $prefix ?>_cable_<?= $i ?>_core" class="form-control" placeholder="Core"></div>
			  <div class="col-md-2"><input name="<?= $prefix ?>_cable_<?= $i ?>_mm" class="form-control" placeholder="MM"></div>
			  <div class="col-md-2"><input name="<?= $prefix ?>_cable_<?= $i ?>_feet" class="form-control" placeholder="Feet"></div>
			  <div class="col-md-2"><input name="<?= $prefix ?>_cable_<?= $i ?>_length" class="form-control" placeholder="Length"></div>
			</div>
		  <?php endfor; ?>
		</div>
	  <?php endforeach; ?>
	</div>


    <div class="form-section">
      <h5>Other Equipment</h5>
      <div class="row">
        <?php
        $others = ['light_arrester','smart_controller','zero_export','light_earthing','delta_hub','ac_earthing','dc_earthing'];
        foreach ($others as $o):
        ?>
        <div class="col-md-4">
          <div class="form-check">
            <input type="checkbox" name="<?= $o ?>" value="1" class="form-check-input" id="<?= $o ?>">
            <label for="<?= $o ?>" class="form-check-label text-capitalize"><?= str_replace('_', ' ', $o) ?></label>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <div class="form-section">
      <h5>Net Metering Status</h5>
      <select name="net_metering_progress" class="form-select mb-3">
        <option>Application Submission</option>
        <option>Survey & Drawing</option>
        <option>Estimate Issuance</option>
        <option>Estimate & SD Payment Recieved</option>
        <option>Test Form Submission (Except Net Metering)</option>
        <option>Material & Execution</option>
        <option>Energisation</option>
        <option>Case Completed</option>
      </select>

      <label>Additional Notes</label>
      <textarea name="notes" class="form-control" rows="3"></textarea>
    </div>

    <div class="d-grid">
      <button class="btn btn-success">Submit Survey</button>
    </div>
  </form>
</div>

<script>
  // Panel Box Inputs
  document.getElementById('panelBoxCount').addEventListener('input', function() {
    const count = parseInt(this.value);
    const container = document.getElementById('panelBoxInputs');
    container.innerHTML = '';
    for (let i = 1; i <= count; i++) {
      const input = document.createElement('input');
      input.name = 'panel_box_' + i;
      input.placeholder = i;
      input.className = 'form-control';
      container.appendChild(input);
    }
  });

  // Inverter Toggle
  document.getElementById('inverterCount').addEventListener('input', function() {
    const val = parseInt(this.value);
    document.getElementById('inverter1').style.display = val >= 1 ? 'block' : 'none';
    document.getElementById('inverter2').style.display = val >= 2 ? 'block' : 'none';
  });

  // Inverter 1 Boxes
  document.getElementById('inv1BoxCount').addEventListener('input', function () {
    const count = parseInt(this.value);
    const container = document.getElementById('inv1BoxInputs');
    container.innerHTML = '';
    for (let i = 1; i <= count; i++) {
      const input = document.createElement('input');
      input.name = 'inv1_box_' + i;
      input.placeholder = i;
      input.className = 'form-control';
      container.appendChild(input);
    }
  });

  // Inverter 2 Boxes
  document.getElementById('inv2BoxCount').addEventListener('input', function () {
    const count = parseInt(this.value);
    const container = document.getElementById('inv2BoxInputs');
    container.innerHTML = '';
    for (let i = 1; i <= count; i++) {
      const input = document.createElement('input');
      input.name = 'inv2_box_' + i;
      input.placeholder = i;
      input.className = 'form-control';
      container.appendChild(input);
    }
  });

  // Battery Toggle
  document.getElementById('batteryInstalled').addEventListener('change', function () {
    document.getElementById('batterySection').style.display = this.checked ? 'block' : 'none';
  });
</script>
</body>
</html>
